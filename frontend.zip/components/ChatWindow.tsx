"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { Message, AIModel, Conversation } from "@/types";
import { MessageBubble } from "./MessageBubble";
import { ChatInput } from "./ChatInput";
import { ScrollArea } from "./ui/scroll-area";
import { Button } from "./ui/button";
import { generateId } from "@/lib/utils";
import { ProviderIcon } from "./ProviderIcon";
import { Trash2, ChevronDown, Loader2 } from "lucide-react";
import { Separator } from "./ui/separator";
import { cn } from "@/lib/utils";
import { sendChatMessage } from "@/lib/api";
import { formatApiError } from "@/lib/utils";

interface ChatWindowProps {
  model: AIModel & { isKeyConfigured?: boolean };
  conversation: Conversation;
  onUpdateConversation: (conv: Conversation) => void;
  onNewConversation: () => void;
}

export function ChatWindow({ model, conversation, onUpdateConversation, onNewConversation }: ChatWindowProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversation.messages, streamingContent]);

  const handleSend = useCallback(async (content: string) => {
    setError(null);

    const userMessage: Message = {
      id: generateId(),
      role: "user",
      content,
      createdAt: new Date(),
    };

    const updatedMessages = [...conversation.messages, userMessage];

    const updatedConv: Conversation = {
      ...conversation,
      messages: updatedMessages,
      title:
        conversation.messages.length === 0
          ? content.slice(0, 50)
          : conversation.title,
      updatedAt: new Date(),
    };

    onUpdateConversation(updatedConv);

    setIsLoading(true);
    setStreamingContent("");

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const apiMessages = updatedMessages.map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      }));

      let fullContent = "";

      await sendChatMessage(
        {
          messages: apiMessages,
          modelId: model.id,
        },
        {
          onChunk: (text) => {
            fullContent += text;
            setStreamingContent(fullContent);
          },

          onDone: () => {
            // opcional: pode usar usage aqui depois
          },

          onError: (err) => {
            throw new Error(err);
          },
        },
        controller.signal
      );

      const assistantMessage: Message = {
        id: generateId(),
        role: "assistant",
        content: fullContent,
        createdAt: new Date(),
        modelId: model.id,
      };

      const finalConv: Conversation = {
        ...updatedConv,
        messages: [...updatedConv.messages, assistantMessage],
        updatedAt: new Date(),
      };

      onUpdateConversation(finalConv);
    } catch (err: unknown) {
      if ((err as Error).name === "AbortError") return;

      const message =
        err instanceof Error ? err.message : "Erro desconhecido";

      setError(formatApiError(message));
    } finally {
      setIsLoading(false);
      setStreamingContent("");
      abortRef.current = null;
    }
  }, [conversation, model, onUpdateConversation]);

  const handleStop = () => {
    abortRef.current?.abort();
    setIsLoading(false);
    setStreamingContent("");
  };

  const handleClear = () => {
    onUpdateConversation({
      ...conversation,
      messages: [],
      title: "Nova conversa",
      updatedAt: new Date(),
    });
    setError(null);
  };

  const isEmpty = conversation.messages.length === 0 && !isLoading;

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-6 py-3 border-b border-zinc-100 dark:border-zinc-800">
        <div className="flex items-center gap-3">
          <ProviderIcon provider={model.provider} className="h-8 w-8" />
          <div>
            <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              {model.name}
            </h2>
            <p className="text-xs text-zinc-400">
              {conversation.title !== "Nova conversa" ? conversation.title : "Nova conversa"}
            </p>
          </div>
        </div>

        <Button
          variant="ghost"
          size="icon-sm"
          onClick={handleClear}
          disabled={conversation.messages.length === 0}
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>

      <div className="flex-1 overflow-hidden">
        {isEmpty ? (
          <div className="flex flex-col items-center justify-center h-full gap-4 px-8">
            <ProviderIcon provider={model.provider} className="h-14 w-14" />
            <div className="text-center">
              <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
                Conversar com {model.name}
              </h3>
              <p className="text-sm text-zinc-400 mt-1 max-w-sm">
                {model.description}
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-2 mt-2">
              {[
                "Explique quantum computing",
                "Escreva um poema",
                "Crie um plano de estudos",
                "Resuma um texto para mim",
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  onClick={() => handleSend(suggestion)}
                  className="text-xs border border-zinc-200 dark:border-zinc-700 rounded-full px-3 py-1.5 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <ScrollArea className="h-full">
            <div className="px-6 py-6 space-y-6 max-w-3xl mx-auto">
              {conversation.messages.map((msg) => (
                <MessageBubble
                  key={msg.id}
                  message={msg}
                  modelName={msg.role === "assistant" ? model.name : undefined}
                />
              ))}

              {isLoading && streamingContent && (
                <MessageBubble
                  message={{
                    id: "streaming",
                    role: "assistant",
                    content: streamingContent,
                    createdAt: new Date(),
                  }}
                  modelName={model.name}
                />
              )}

              {isLoading && !streamingContent && (
                <div className="flex gap-3">
                  <div className="h-7 w-7 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center">
                    <Loader2 className="h-3.5 w-3.5 animate-spin text-zinc-400" />
                  </div>
                  <div className="flex items-center gap-1 pt-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-zinc-300 dark:bg-zinc-600 animate-bounce [animation-delay:-0.3s]" />
                    <span className="h-1.5 w-1.5 rounded-full bg-zinc-300 dark:bg-zinc-600 animate-bounce [animation-delay:-0.15s]" />
                    <span className="h-1.5 w-1.5 rounded-full bg-zinc-300 dark:bg-zinc-600 animate-bounce" />
                  </div>
                </div>
              )}

              {error && (
                <div className="flex justify-center">
                  <div className="text-sm text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 rounded-xl px-4 py-3 max-w-sm text-center">
                    {error}
                  </div>
                </div>
              )}

              <div ref={bottomRef} />
            </div>
          </ScrollArea>
        )}
      </div>

      <div className="px-4 pb-4 pt-2 max-w-3xl mx-auto w-full">
        <ChatInput
          onSend={handleSend}
          isLoading={isLoading}
          onStop={handleStop}
          disabled={!model.isKeyConfigured}
          placeholder={
            !model.isKeyConfigured
              ? "Configure a chave de API no .env.local"
              : `Mensagem para ${model.name}...`
          }
        />
        <p className="text-center text-xs text-zinc-300 dark:text-zinc-700 mt-2">
          Enter para enviar · Shift+Enter para nova linha
        </p>
      </div>
    </div>
  );
}
