# agente-bot

Interface de chat com múltiplos modelos de IA — Anthropic, Google e OpenAI — em um só lugar.

## Configuração

1. Copie o arquivo de exemplo:
   ```bash
   cp .env.example .env.local
   ```

2. Adicione suas chaves de API no `.env.local`:
   ```env
   ANTHROPIC_API_KEY=sk-ant-...
   OPENAI_API_KEY=sk-...
   GOOGLE_GENERATIVE_AI_API_KEY=AIza...
   ```

3. Instale as dependências e rode:
   ```bash
   npm install
   npm run dev
   ```

## Rotas de API

| Rota | Método | Descrição |
|------|--------|-----------|
| `/api/ia/models` | GET | Lista todos os modelos com status de disponibilidade |
| `/api/chat` | POST | Envia mensagem e recebe resposta em streaming (SSE) |
