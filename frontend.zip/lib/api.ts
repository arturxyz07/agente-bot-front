const API_URL = "https://agente-bot-api.vercel.app";

/**
 * Fetch padrão (JSON)
 */
export async function fetcher(path: string, options?: RequestInit) {
  const res = await fetch(`${API_URL}${path}`, options);

  if (!res.ok) {
    let err;
    try {
      err = await res.json();
    } catch {
      throw new Error(res.statusText);
    }
    throw new Error(err.message || err.error || res.statusText);
  }

  return res.json();
}

/**
 * Fetch para STREAM (SSE)
 */
export async function streamFetcher(path: string, options?: RequestInit) {
  const res = await fetch(`${API_URL}${path}`, options);

  if (!res.ok) {
    let err;
    try {
      err = await res.json();
    } catch {
      throw new Error(res.statusText);
    }
    throw new Error(err.message || err.error || res.statusText);
  }

  return res; // 👈 importante: NÃO faz json()
}

/**
 * Consumidor de SSE (sua API /api/chat)
 */
export async function consumeChatStream(
  response: Response,
  handlers: {
    onChunk: (text: string) => void;
    onDone?: (usage: any) => void;
    onError?: (error: string) => void;
  }
) {
  const reader = response.body?.getReader();
  const decoder = new TextDecoder();

  if (!reader) throw new Error("Sem stream de resposta");

  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split("\n");
    buffer = lines.pop() || "";

    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;

      const jsonStr = line.replace("data: ", "").trim();
      if (!jsonStr) continue;

      const data = JSON.parse(jsonStr);

      if (data.type === "chunk") {
        handlers.onChunk(data.content);
      }

      if (data.type === "done") {
        handlers.onDone?.(data.usage);
      }

      if (data.type === "error") {
        handlers.onError?.(data.message);
        throw new Error(data.message);
      }
    }
  }
}

/**
 * API: pegar modelos
 */
export function getModels() {
  return fetcher("/api/ia/models");
}

/**
 * API: chat com stream
 */
export async function sendChatMessage(
  body: {
    messages: any[];
    modelId: string;
  },
  handlers: {
    onChunk: (text: string) => void;
    onDone?: (usage: any) => void;
    onError?: (error: string) => void;
  },
  signal?: AbortSignal
) {
  const response = await streamFetcher("/api/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
    signal,
  });

  await consumeChatStream(response, handlers);
}