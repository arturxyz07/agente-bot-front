"use client";

import { useState, useEffect, useCallback } from "react";
import { AIModel, Conversation } from "@/types";
import { ModelSelector } from "@/components/ModelSelector";
import { ChatWindow } from "@/components/ChatWindow";
import { WelcomeScreen } from "@/components/WelcomeScreen";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { generateId } from "@/lib/utils";
import { ProviderIcon } from "@/components/ProviderIcon";
import { Plus, MessageSquare, PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { cn } from "@/lib/utils";
import { getModels } from "@/lib/api";

export default function Home() {
  const [models, setModels] = useState<(AIModel & { isKeyConfigured?: boolean })[]>([]);
  const [selectedModel, setSelectedModel] = useState<(AIModel & { isKeyConfigured?: boolean }) | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getModels()
      .then((data) => setModels(data.models || []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const activeConversation = conversations.find((c) => c.id === activeConversationId);

  const handleSelectModel = useCallback((model: AIModel) => {
    const fullModel = models.find((m) => m.id === model.id) || model;
    setSelectedModel(fullModel as AIModel & { isKeyConfigured?: boolean });

    const existing = conversations.find(
      (c) => c.modelId === model.id && c.messages.length === 0
    );

    if (existing) {
      setActiveConversationId(existing.id);
    } else {
      const newConv: Conversation = {
        id: generateId(),
        title: "Nova conversa",
        modelId: model.id,
        messages: [],
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      setConversations((prev) => [newConv, ...prev]);
      setActiveConversationId(newConv.id);
    }
  }, [models, conversations]);

  const handleNewConversation = useCallback(() => {
    if (!selectedModel) return;
    const newConv: Conversation = {
      id: generateId(),
      title: "Nova conversa",
      modelId: selectedModel.id,
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setConversations((prev) => [newConv, ...prev]);
    setActiveConversationId(newConv.id);
  }, [selectedModel]);

  const handleUpdateConversation = useCallback((conv: Conversation) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === conv.id ? conv : c))
    );
  }, []);

  const handleSelectConversation = (conv: Conversation) => {
    setActiveConversationId(conv.id);
    const model = models.find((m) => m.id === conv.modelId);
    if (model) setSelectedModel(model);
  };

  const modelConversations = conversations.filter(
    (c) => selectedModel && c.modelId === selectedModel.id
  );

  return (
    <div className="flex h-screen bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100">
      <div
        className={cn(
          "flex flex-col border-r border-zinc-100 dark:border-zinc-800 transition-all duration-200 overflow-hidden",
          sidebarOpen ? "w-72" : "w-0"
        )}
      >
        {sidebarOpen && (
          <div className="flex flex-col h-full w-72">
            <ModelSelector
              models={models}
              selectedModelId={selectedModel?.id ?? null}
              onSelect={handleSelectModel}
            />
          </div>
        )}
      </div>

      <div className="flex flex-col flex-1 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-2 border-b border-zinc-100 dark:border-zinc-800">
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={() => setSidebarOpen((v) => !v)}
          >
            {sidebarOpen ? (
              <PanelLeftClose className="h-4 w-4" />
            ) : (
              <PanelLeftOpen className="h-4 w-4" />
            )}
          </Button>

          {selectedModel && (
            <>
              <Separator orientation="vertical" className="h-4" />
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <ProviderIcon provider={selectedModel.provider} className="h-6 w-6" />
                <span className="text-sm font-medium truncate">{selectedModel.name}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleNewConversation}
                className="gap-1.5 text-xs"
              >
                <Plus className="h-3.5 w-3.5" />
                Nova
              </Button>
            </>
          )}

          {!selectedModel && !sidebarOpen && (
            <span className="text-sm font-semibold">agente-bot</span>
          )}
        </div>

        {selectedModel && modelConversations.length > 1 && (
          <div className="flex items-center gap-1 px-4 py-1.5 border-b border-zinc-100 dark:border-zinc-800 overflow-x-auto">
            {modelConversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => handleSelectConversation(conv)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs whitespace-nowrap transition-colors shrink-0",
                  conv.id === activeConversationId
                    ? "bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100"
                    : "text-zinc-500 hover:bg-zinc-50 dark:hover:bg-zinc-900"
                )}
              >
                <MessageSquare className="h-3 w-3" />
                {conv.title.slice(0, 25)}
                {conv.title.length > 25 && "..."}
              </button>
            ))}
          </div>
        )}

        <div className="flex-1 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <div className="flex flex-col items-center gap-3">
                <div className="h-8 w-8 rounded-full border-2 border-zinc-200 border-t-zinc-600 animate-spin" />
                <p className="text-sm text-zinc-400">Carregando modelos...</p>
              </div>
            </div>
          ) : selectedModel && activeConversation ? (
            <ChatWindow
              key={activeConversationId}
              model={selectedModel}
              conversation={activeConversation}
              onUpdateConversation={handleUpdateConversation}
              onNewConversation={handleNewConversation}
            />
          ) : (
            <WelcomeScreen
              availableModels={models}
              onSelect={handleSelectModel}
            />
          )}
        </div>
      </div>
    </div>
  );
}
